#!/usr/bin/perl 

# ���������ļ���
$counter_file='count.dat';

#���ļ�������


if (-T $counter_file) {
  open(FILE, $counter_file) || die $!;
  $count = <FILE>;
  close (FILE);
  $count+=1;
  } else {  
    $count=1; 
  }

open (FILE, ">$counter_file");
print FILE $count;
close (FILE);

#�����ӳ���������
&initialize;
&generateBitmap;
&writeBitmap;
exit;

#��ʼ��ͼ�������ӳ���
sub initialize {
   $minLen = 6;           #��С����
   $isHigh = 1;           #����0ʱ������10λ�ߣ�����1ʱ������16λ�ߣ����˱߽�
   $isInverse = 0;        #0ʱ�׵׺��֣�1ʱ�ڵװ���
   #����λͼ��8λ��10λ�ߣ�@invdigitsΪ�ڵװ��֣�@digitsΪ�׵׺���
   @invdigits = ("c3 99 99 99 99 99 99 99 99 c3",  # 0
                 "cf c7 cf cf cf cf cf cf cf c7",  # 1
                 "c3 99 9f 9f cf e7 f3 f9 f9 81",  # 2
                 "c3 99 9f 9f c7 9f 9f 9f 99 c3",  # 3
                 "cf cf c7 c7 cb cb cd 81 cf 87",  # 4
                 "81 f9 f9 f9 c1 9f 9f 9f 99 c3",  # 5
                 "c7 f3 f9 f9 c1 99 99 99 99 c3",  # 6
                 "81 99 9f 9f cf cf e7 e7 f3 f3",  # 7
                 "c3 99 99 99 c3 99 99 99 99 c3",  # 8
                 "c3 99 99 99 99 83 9f 9f cf e3"); # 9


      @digits = ("3c 66 66 66 66 66 66 66 66 3c",  # 0
                 "30 38 30 30 30 30 30 30 30 30",  # 1
                 "3c 66 60 60 30 18 0c 06 06 7e",  # 2
                 "3c 66 60 60 38 60 60 60 66 3c",  # 3
                 "30 30 38 38 34 34 32 7e 30 78",  # 4
                 "7e 06 06 06 3e 60 60 60 66 3c",  # 5
                 "38 0c 06 06 3e 66 66 66 66 3c",  # 6
                 "7e 66 60 60 30 30 18 18 0c 0c",  # 7
                 "3c 66 66 66 3c 66 66 66 66 3c",  # 8
                 "3c 66 66 66 66 7c 60 60 30 1c"); # 9
}

#λͼ�����ӳ���
sub generateBitmap {
   @bytes = ();
   $len = length($count) > $minLen ? length($count) : $minLen;
   $formattedCount = sprintf("%0${len}d",$count);
   if ($isHigh) {
      for ($i = 0; $i < $len*4; $i++ ) {
         if ($isInverse) {
            push(@bytes,"ff");       # ÿλ�����������п���
         }
         else {
            push(@bytes,"00");
         }
      }
   }
   for ($y=0; $y < 10; $y++) {
       for ($x=0; $x < $len; $x++) {
           $digit = substr($formattedCount,$x,1);
           if ($isInverse) {             
               $byte = substr(@invdigits[$digit],$y*3,2);
           }
           else {
               $byte = substr(@digits[$digit],$y*3,2);
           }
           push(@bytes,$byte);
       }
   }
   if ($isHigh) {
      for ($i = 0; $i < $len*4; $i++ ) {
         if ($isInverse) {
            push(@bytes,"ff");       # ÿλ�����������п���
         }
         else {
            push(@bytes,"00");
         }
      }
   }
}

#λͼ����ӳ���
sub writeBitmap {
print "Content-type: image/x-xbitmap\n\n";
   if ($isHigh) {
      printf ("#define count_width %d\n#define count_height 16\n",
              $len*8);
   }
   else {
      printf ("#define count_width %d\n#define count_height 10\n",
              $len*8);
   }
   printf STDOUT "static char count_bits[] = {\n";
   for($i = 0; $i < ($#bytes + 1); $i++) {
      print("0x$bytes[$i]");
      if ($i != $#bytes) {
         print(",");
         if (($i+1) % 7 == 0) {
            print("\n");
         }
      }
   }
   print("};\n");
}
